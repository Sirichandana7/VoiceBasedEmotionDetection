from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from pathlib import Path

import librosa
import soundfile
import os, glob, pickle
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

import requests as r
import json


BASE_DIR = Path(__file__).resolve().parent.parent

def index(request):
    def extract_feature(file_name, mfcc, chroma, mel):
        with soundfile.SoundFile(file_name) as sound_file:
            X = sound_file.read(dtype="float32")
            sample_rate=sound_file.samplerate
            if chroma:
                stft=np.abs(librosa.stft(X))
            result=np.array([])
            if mfcc:
                mfccs=np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
                result=np.hstack((result, mfccs))
            if chroma:
                chroma=np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T,axis=0)
                result=np.hstack((result, chroma))
            if mel:
                mel=np.mean(librosa.feature.melspectrogram(X, sr=sample_rate).T,axis=0)
                result=np.hstack((result, mel))
        return result

    if request.method == "POST":
        my_uploaded_file = request.FILES['my_uploaded_file'].read()

        name = "test"
        number = "1"
        file_name = "{}{}.wav".format(os.path.join(BASE_DIR, 'myapp/static/'),name+"_"+number)
        print(file_name)
        with open(file_name,'wb') as f:
            f.write(my_uploaded_file)

        modelname = 'trained_model.sav'

        path = os.path.join(BASE_DIR, 'myapp/static/')
        print(path)
        
        loaded_model = pickle.load(open(modelname, 'rb')) # loading the model file from the storage

        feature=extract_feature(file_name, mfcc=True, chroma=True, mel=True)

        feature=feature.reshape(1,-1)

        prediction=loaded_model.predict(feature)

        print(prediction)

        service_plan_id = "ec9eae3c15704184b8aff9b7ba21c742"
        access_token    = "b0ca53e01801441da0d4a54def053b48"

        from_ = "447520651530"
        to_   = "918439321860"

        message = "Emotion Detected : "+str(prediction[0])

        headers = {
            "Authorization":f"Bearer {access_token}",
            "Content-Type":"application/json"
        }

        payload = {
            "from":from_,
            "to":[to_],
            "body":message
        }
        response = r.post(
            f'https://sms.api.sinch.com/xms/v1/{service_plan_id}/batches',
            headers=headers,
            data=json.dumps(payload)
        ).json()

        print(response)

        return render(request, "index.html",context = {"mymessage":"Emotion Detected : "+str(prediction[0]),"Flag":"True"})

    return render(request, "index.html")